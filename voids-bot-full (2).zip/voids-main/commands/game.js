const { SlashCommandBuilder } = require('discord.js');
const g = require('../utils/games');
const g2 = require('../utils/games2');
const { stopGame } = require('../utils/gameKit');

const GAMES = [
  ['last-typer', 'Keep sending messages. Miss the timer and you are out', g.lastTyper],
  ['closest', 'Guess a number from 1 to 1000. Closest wins', g.closest],
  ['roulette', 'One random player is eliminated each round', g.roulette],
  ['boats', 'Text boat race. First across the line wins', g.boats],
  ['rps-tournament', 'Rock paper scissors knockout tournament', g.rpsTournament],
  ['hot-potato', 'Pass the potato before it blows up', g.hotPotato],
  ['typing-race', 'First to type the sentence wins the round', g.typingRace],
  ['trivia', 'Trivia knockout. Wrong answers are out', g.trivia],
  ['dice', 'Highest dice roll wins, ties reroll', g.dice],
  ['chests', 'Pick a chest. Only some hold the prize', g.chests],
  ['button', "Don't press the button", g.dontPress],
  ['number-elim', 'Pick numbers. The losing number is eliminated', g.numberElim],
  ['word-scramble', 'Unscramble the word before anyone else', g2.wordScramble],
  ['math-race', 'First to solve the sum wins the round', g2.mathRace],
  ['reaction', 'Press the button the moment it turns green', g2.reactionTest],
  ['defuse', 'Cut the right wire or the bomb takes you out', g2.defuse],
  ['heads-or-tails', 'Guess the coin flip. Wrong guesses are out', g2.headsOrTails],
  ['memory-match', 'Memorise the emojis and type them back', g2.memoryMatch],
];

const data = new SlashCommandBuilder()
  .setName('game')
  .setDescription('Start a mini game')
  .setDMPermission(false);

for (const [name, description] of GAMES) {
  data.addSubcommand((sub) =>
    sub
      .setName(name)
      .setDescription(description)
      .addStringOption((opt) =>
        opt.setName('prize').setDescription('Prize for the winner, e.g. 5m (staff only)').setMaxLength(100).setRequired(false)
      )
  );
}

data.addSubcommand((sub) =>
  sub.setName('stop').setDescription('Stop the game running in this channel')
);

module.exports = {
  data,

  async execute(interaction) {
    const name = interaction.options.getSubcommand();
    if (name === 'stop') return stopGame(interaction);
    const game = GAMES.find(([n]) => n === name);
    if (!game) return;
    await game[2](interaction);
  },
};
